# WebTechVerse homepage

Static site: `index.html` + `assets/`. No build step.

## Deploy on Vercel
1. Push this folder to a GitHub repo (or drag the folder into vercel.com/new).
2. Framework preset: **Other**. Build command: none. Output directory: `./` (root).
3. Deploy. Add `webtechverse.com` under Project → Settings → Domains when ready.

Animations use GSAP 3.12.5, ScrollTrigger and Lenis 1.1.13, loaded from CDNs.
Social links in the footer are placeholders (`href="#"`); add the real URLs.
